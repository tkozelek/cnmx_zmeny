<x-layout :title="$title">
    @if(isset($days) && count($days) != 0)
        @if(auth()->user()->hasRole(config('constants.roles.admin')))
            @include('partials._adminbutton')
        @else
            @include('partials._nonadminbutton')
        @endif
        <x-date :week="$week" />
        <section class="md:container mx-auto">
            <div class="text-center mb-2">
                @include('partials._toggle')
                @include('partials._extratext')
            </div>
            <div
                class="text-center grid-flow-row auto-rows-max grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-7 2xl:grid-cols-7 gap-3">
                @foreach($days as $day)
                    <x-one-day :day="$day" :locked="$week->locked"/>
                @endforeach
            </div>

            <div class="flex mt-10 mb-5">
                @if(isset($userCount) && count($userCount) != 0)
                    <div class="">
                        <table class="table-auto border border-gray-800 bg-slate-900 text-gray-200">
                            <thead>
                                <tr class="">
                                    <x-table-cell-header>Meno</x-table-cell-header>
                                    <x-table-cell-header>Počet</x-table-cell-header>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($userCount as $user)
                                    <x-table-row>
                                        <x-table-cell-header>{{ $user }}</x-table-cell-header>
                                        <x-table-cell>{{ $user->count }}</x-table-cell>
                                    </x-table-row>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                @endif
            </div>
            <div class="flex">
                @if(isset($absences) && count($absences) != 0)
                    <div class="overflow-x-auto">
                        <table class="table-auto border border-gray-800 bg-slate-900 text-gray-200">
                            <thead class="">
                            <tr class="">
                                <x-table-cell-header>Meno</x-table-cell-header>
                                <x-table-cell-header>Začiatok</x-table-cell-header>
                                <x-table-cell-header>Koniec</x-table-cell-header>
                                <x-table-cell-header>Dôvod</x-table-cell-header>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($absences as $absence)
                                <x-table-row>
                                    <x-table-cell-header>{{ $absence->user }}</x-table-cell-header>
                                    <x-table-cell>{{ App\Helpers::getDateFromAttribute($absence->date_from, 'd.m.Y') }}</x-table-cell>
                                    <x-table-cell>{{ App\Helpers::getDateFromAttribute($absence->date_to, 'd.m.Y') }}</x-table-cell>
                                    <x-table-cell>{{ $absence->popis }}</x-table-cell>
                                </x-table-row>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                @endif
            </div>
        </section>
    @else
        <p>no found</p>
    @endif

</x-layout>
