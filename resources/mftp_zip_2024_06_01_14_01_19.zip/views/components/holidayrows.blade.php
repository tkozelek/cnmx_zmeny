@props(['holidays', 'name'])

@isset($holidays)

@endisset
