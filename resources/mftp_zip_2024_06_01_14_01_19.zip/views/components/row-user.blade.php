<div {{$attributes->merge(['class' => 'bg-gray-900 text-white border-b border-gray-700 py-1 shadow-md rows'])}}>
    {{ $slot }}
</div>



