<tr {{ $attributes->merge(['class' => "border-b bg-gray-800 border-gray-700 hover:bg-gray-900 hover:text-white"]) }}>
    {{ $slot }}
</tr>
