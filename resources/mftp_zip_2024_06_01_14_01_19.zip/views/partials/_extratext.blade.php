<div class="md:flex md:items-center mb-2">
    <div class="w-full md:w-4/5">
        <label class="block text-gray-300 font-bold md:text-right mb-1 md:mb-0 pr-4" for="extra_popis">
            Extra info
        </label>
    </div>
    <div class="md:w-1/5">
        <input class="bg-gray-200 border-2 border-gray-200 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-gray-900" id="extra_popis" type="text" placeholder="od 15">
    </div>
</div>
